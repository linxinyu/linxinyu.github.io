This supplemental material includes two parts: matlab figure and video of chair 3D mesh model with 3D interest points detected by seven algorithms.

For matlab figure, you can open it with matlab software and choose "Tools -> Rotate 3D" option to view the 3D effect of three matlab figure. 

For video, you can open it with any video player which supports the format of "*.mp4".

If you have any question, please contact us through email: xinyulin@std.uestc.edu.cn