clc
clear all
close all
format long

%%
scale = 6;
IP_sum = 0;
load chair_4

points_num = size(V,1);
[smoothing_model] = gaussian_scale_space(V,F,scale);

%%
%Load or get neighborhood rings for every vertex in a 3D mesh model
load NP_first 
load NP_second
load NP_third
load NP_four
% [NP_first,NP_second,NP_third,NP_four] = cal_NearPoints(V,F);

%%
%Calculate 3D saliency measure for every vertex in a 3D mesh model
disp('Calculate 3D saliency measure for every vertex in a 3D mesh model ...')
score_final = [];
score_p = ones(points_num,1);
for j = 1:size(smoothing_model,2)
    V = smoothing_model{1,j};
    F = F;
    [V_normals] = cal_normals(V,F);
    [score] = cal_features(V,F,NP_first,NP_second,NP_third,NP_four,V_normals);
    score_p = score .* score_p;
    score_final = [score_final;score'];
end

%%
%Select candidates of 3D interest points
disp('Select candidates of 3D interest points ...')
score_p = score_p ./ max(score_p);
score_p_copy = score_p;
for k = 1:points_num
    np_1 = NP_first{1,k};
    np_2 = NP_second{1,k};
    np_3 = NP_third{1,k};
    np_4 = NP_four{1,k};
    nearpoints = [k;np_1;np_2;np_3;np_4];
    
    temp_scores = score_p(nearpoints);
    [a,b] = max(temp_scores);
    if nearpoints(b) ~= k
        score_p_copy(k) = 0;
    end
end
nonmaxima_index = find(score_p_copy > 0);

score_p_nonmaxima = score_p(nonmaxima_index);
score_final_nonmaxima = score_final(:,nonmaxima_index);
h = figure;
set(h, 'position', get(0,'ScreenSize'));
title('3D Saliency measures of candidates of 3D interest points at 7 scales')
col = ['c','m','y','k','b','g','r'];
for i = 1:scale+1
    hold on
    plot(score_final_nonmaxima(i,:),col(i),'LineWidth',1.5)
end
legend('scale - 0','scale - 1','scale - 2','scale - 3','scale - 4','scale - 5','scale - 6')
hold off

h = figure;
set(h, 'position', get(0,'ScreenSize'));
plot(score_p_nonmaxima,'LineWidth',1.5)
title('Final 3D Saliency measures of candidates of 3D interest points')

%%
%Sparse refinement
disp('Sparse refinement ...')
nonmaxima_scores = score_p(nonmaxima_index)';
mean_nonmaxima_scores = mean(nonmaxima_scores);
[top_a top_b] = find(nonmaxima_scores > 2*mean_nonmaxima_scores);
nonmaxima_scores(top_b) = 2*mean_nonmaxima_scores;
nonmaxima_scores = nonmaxima_scores ./ max(nonmaxima_scores);

[final_scores, min_cost] = myopt(nonmaxima_scores, 0.00001);
disp('Final 3D Saliency measures of candidates of 3D interest points after mapping')
disp(nonmaxima_scores)
disp('Final 3D Saliency measures of candidates of 3D interest points after sparse refinement')
disp(final_scores)

% Please use 'Tools -> Zoom out' to view the curves (especially for horizontal axis 88 and 61)
opt_index = find(final_scores > 0);
IP_vertex_indices = nonmaxima_index(opt_index);
IP_sum = IP_sum + length(IP_vertex_indices);
[~,points_scale] = max(score_final(:,IP_vertex_indices));

%%
%Final 3D interest point set
interest_point_set =  [smoothing_model{1,1}(IP_vertex_indices,:)];

%%
h = figure;
set(h, 'position', get(0,'ScreenSize'));
trisurf(F,smoothing_model{1,1}(:,1),smoothing_model{1,1}(:,2),smoothing_model{1,1}(:,3),ones(length(F),1),'edgealpha',0);
material dull; lightangle(0,180); lighting gouraud; colormap(gray);
daspect([1 1 1]); axis off; view(0,180);

% Plot candidates of 3D interest points
hold on;
plot3(smoothing_model{1,1}(nonmaxima_index,1),smoothing_model{1,1}(nonmaxima_index,2),smoothing_model{1,1}(nonmaxima_index,3),'.g','MarkerSize',20)
% Plot final 3D interest points
hold on
plot3(smoothing_model{1,1}(IP_vertex_indices,1),smoothing_model{1,1}(IP_vertex_indices,2),smoothing_model{1,1}(IP_vertex_indices,3),'or','MarkerSize',10)
title('Candidates of 3D interest points (green dots) and final 3D interest points (red circles)')